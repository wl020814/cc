#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, const char *argv[])
{
	int fd;
	int value=0;
	fd = open("/dev/led0",O_RDWR);
	if(fd<0)
	{
		perror("fd");
		exit(1);
	}
	
	read(fd,&value,sizeof(value));
	printf("value=%d\n",value);

	//驱动已经准备好了灯的功能，应用层看我们表演了
	
	while(1)
	{
		value = 1;
		write(fd,&value,sizeof(value));
		sleep(1);

		value = 0;
		write(fd,&value,sizeof(value));
		sleep(1);

	}


	close(fd);

	return 0;
}
