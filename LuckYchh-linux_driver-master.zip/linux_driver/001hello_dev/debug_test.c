#include <linux/init.h>
#include <linux/module.h>
//#include "pritdebug.h"

#ifdef PDEBUG
	#define PLOG(fmt,args...) printk(KERN_DEBUG fmt,##args)
#else
	#define PLOG(fmt,args...) /*do nothing */
#endif


static int __init hello_drv_init(void)
{
	int a=10;
	printk("--------start----------\n");
	PLOG("-------welcom!--------\n");
	PLOG("a=%d\n",a);
	return 0;
}

static void __exit hello_drv_exit(void)
{
	PLOG("-------BYE!--------\n");	
}


module_init(hello_drv_init);
module_exit(hello_drv_exit);
MODULE_LICENSE("GPL");






