#ifndef PRINTDEBUG_H
#define PRINTDEBUG_H

#ifdef PDEBUG
#define PLOG(fmt,args...) printk(KERN_DEBUG fmt,##args)
#else
#define PLOG(fmt,args...) /*do nothing */

#endif


#endif
