#ifndef __MATH_H__
#define __MATH_H__

int myadd(int a,int b);
int mysub(int a,int b);

#endif
