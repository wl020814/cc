#include <linux/init.h>
#include <linux/module.h>

int myadd(int a,int b)
{
	return a+b;
}

EXPORT_SYMBOL(myadd);

int mysub(int a,int b)
{
	return a-b;
}

EXPORT_SYMBOL(mysub);

MODULE_LICENSE("GPL");




