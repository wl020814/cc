#include <linux/init.h>
#include <linux/module.h>
//#include <linux/stat.h>

#include "math.h"

static char *name="HUAWEI";
static int age=23;

module_param(age,int,0644);
module_param(name,charp,S_IRUGO|S_IWUSR);

static int __init hello_drv_init(void)
{
	printk("-------welcom!--------\n");
	printk("name: %s,age: %d\n",name,age);
	printk("a+b=%d,a-b=%d\n",myadd(10,20),mysub(23,14));
	return 0;
}

static void __exit hello_drv_exit(void)
{
	printk("-------BYE!--------\n");	
}


module_init(hello_drv_init);
module_exit(hello_drv_exit);
MODULE_LICENSE("GPL");






