#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>



int led_pdrv_probe(struct platform_device *pdev)
{
	printk("-----probe-------\n");
	return 0;
}

int led_pdrv_remove(struct platform_device *pdev)
{
	printk("-----remove-------\n");
	return 0;
}


const struct platform_device_id led_id_table[]={
	{"exynos4412_led",0x4444},
	{"exynos6818_led",0x4444},
};

struct platform_driver led_pdrv={
	.probe=led_pdrv_probe,
	.remove=led_pdrv_remove,
	.driver={
		.name = "samsung_led_drv",
		
	},
	.id_table=led_id_table,
};




static int __init drv_led_init(void)
{
	return platform_driver_register(&led_pdrv);
}

static void __exit drv_led_exit(void)
{
	platform_driver_unregister(&led_pdrv);
}

module_init(drv_led_init);
module_exit(drv_led_exit);
MODULE_LICENSE("GPL");
