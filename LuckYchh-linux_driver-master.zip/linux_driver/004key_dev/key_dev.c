#include <linux/init.h>
#include <linux/module.h>
#include <linux/of_irq.h>
#include <linux/of.h>
#include <linux/interrupt.h>
/*
//描述按键信息
struct key_desc{
	unsigned int dev_major;
	struct class *cls;
	struct device *dev;
	int irqnum;
}*/

static int irqnum;

//struct key_desc key_dev;

irqreturn_t key_irq_handler(int irqnum,void *devid)
{
	printk("---------key3-------\n");
	return IRQ_HANDLED;

}

int get_irqno_from_node(void)
{
	int irqnum;
	//名字为节点
	struct device_node *np = of_find_node_by_path("/key_init_node");
	if(np)
	{
		printk("find node ok\n");
	}
	else
	{
		printk("find node failed\n");
	}

	irqnum=irq_of_parse_and_map(np,0);
	printk("irqnum=%d\n",irqnum);
	return irqnum;
}

static int __init key_drv_init(void)
{
	int ret;
	//四部曲：
	//设定一个全局设备对象
//	key_dev=kmalloc()
	//申请主设备号
	//创建设备节点文件
	//硬件的初始化
	
	irqnum=get_irqno_from_node();
	//key3用来查看中断名
	ret = request_irq(irqnum,key_irq_handler,IRQF_TRIGGER_FALLING|IRQF_TRIGGER_RISING,"key3",NULL);
	if(ret != 0)
	{
		printk("request_irq failed\n");
		return ret;
	}
	return 0;
}

static void __exit key_drv_exit(void)
{
 	free_irq(irqnum,NULL);
}

module_init(key_drv_init);
module_exit(key_drv_exit);
MODULE_LICENSE("GPL");

