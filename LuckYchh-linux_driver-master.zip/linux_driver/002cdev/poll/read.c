#include <stdio.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define DEVICE1   "/dev/c0_0"
#define DEVICE2   "/dev/c0_1"

int main()
{
	int ret;
	struct pollfd fds[2];
	char buf0[64];
	char buf1[64];

	fds[0].fd = open(DEVICE1,O_RDWR);
	if(fds[0].fd==-1)
	{
		printf("open %s failed\n",DEVICE1);
		return -1;
	}
	fds[0].events = POLLIN;

	fds[1].fd = open(DEVICE2,O_RDWR);
	if(fds[1].fd==-1)
	{
		printf("open %s failed\n",DEVICE2);
		return -1;
	}
	fds[1].events = POLLIN;

	while(1)
	{
		ret = poll(fds,2,-1);
		if(ret == -1)
		{
			printf("poll failed\n");
			return -1;
		}

		if(fds[0].revents & POLLIN)
		{
			ret = read(fds[0].fd,buf0,64);
			printf("buf0 : %s\n",buf0); 
		}
		if(fds[1].revents & POLLIN)
		{
			ret = read(fds[1].fd,buf1,64);
			printf("buf1 : %s\n",buf1); 
		}
	}



	return 0;
}
