#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#define DEVICE1 "/dev/c0_0"
#define DEVICE2 "/dev/c0_1"

int main()
{
	int fd1,fd2;
	int ret;
	char buf1[64]="from device1";
	char buf2[64]="from device2";
	while(1)
	{
		fd1 = open(DEVICE1,O_RDWR | O_NONBLOCK);
		if(fd1<0)
		{
			perror("fd open DEVICE1");
			exit(1);
		}
		fd2 = open(DEVICE2,O_RDWR | O_NONBLOCK);
		if(fd2<0)
		{
			perror("fd open DEVICE2");
			exit(1);
		}
		ret = write(fd1,buf1,strlen(buf1)+1);  //'\0'
		printf("buf1 size : %d write %d bytes\n",strlen(buf1)+1,ret);
		sleep(8);
		ret = write(fd2,buf2,strlen(buf2)+1);  //'\0'
		printf("buf2 size : %d write %d bytes\n",strlen(buf2)+1,ret);
		sleep(10);
	}

	close(fd1);
	close(fd2);
	return 0;
}

