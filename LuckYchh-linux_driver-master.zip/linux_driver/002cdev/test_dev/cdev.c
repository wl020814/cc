#include <linux/module.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/kfifo.h>
#include <linux/device.h>

#define BUF_SIZE 64
#define KFIFO 
DEFINE_KFIFO(kbuf,char,BUF_SIZE);

struct c0_dev{
	dev_t dev_num;
	struct cdev *mydev;
	char buf[BUF_SIZE];
	struct class *devcls;
};
struct c0_dev *c0;

int c0_open(struct inode *inode,struct file *file)
{
	int major=MAJOR(inode->i_rdev);
	int minor=MINOR(inode->i_rdev);
	printk("%s major : %d, minor : %d\n",__func__,major,minor);
	return 0;
}
int c0_close(struct inode *inode,struct file *file)
{
	printk("%s\n",__func__);
	return 0;
}

#ifdef KFIFO
ssize_t c0_read(struct file *filp,char __user *buf,size_t count,loff_t *ppos)
{
	int readed_size;
	int ret;
	ret = kfifo_to_user(&kbuf,buf,count,&readed_size);
	if(ret)
		return -EIO;
	printk("readed_size = %d, pos = %lld\n",readed_size,*ppos);
	return readed_size;
}
ssize_t c0_write(struct file *filp,const char __user *buf,size_t count,loff_t *ppos)
{
	int written_size;
	int ret;
	ret = kfifo_from_user(&kbuf,buf,count,&written_size);
	if(ret)
		return -EIO;
	printk("written_size = %d, pos = %lld\n",written_size,*ppos);
	return written_size;
}

#else

ssize_t c0_read(struct file *filp,char __user *buf,size_t count,loff_t *ppos)
{
	printk("%s\n",__func__);
	int readed_size,remain_size,free_size;
	int ret;
	free_size = BUF_SIZE - *ppos;
	remain_size = free_size > count? count : free_size;
	if(remain_size==0)
		printk("no space read\n");
	ret = copy_to_user(buf,c0->buf+*ppos,remain_size);
	if(ret == remain_size)
		return -EFAULT;
	readed_size = remain_size - ret;
	*ppos += readed_size;

	printk("readed_size = %d , pos = %lld \n", readed_size, *ppos);
	return readed_size;
}
ssize_t c0_write(struct file *filp,const char __user *buf,size_t count,loff_t *ppos)
{
	printk("%s\n",__func__);
	int written_size,remain_size,free_size;
	int ret;
	free_size = BUF_SIZE - *ppos;
	remain_size = free_size > count? count : free_size;
	if(remain_size==0)
		printk("no space write\n");
	ret = copy_from_user(c0->buf+*ppos,buf,remain_size);
	if(ret == remain_size)
		return -EFAULT;
	written_size = remain_size - ret;
	*ppos += written_size;

	printk("written_size = %d , pos = %lld \n", written_size, *ppos);
	return written_size;
}
#endif

const struct file_operations c0_fops={
	.open    = c0_open,
	.read    = c0_read,
	.write   = c0_write,
	.release = c0_close,
};

static int __init dev_init(void)
{
	int ret;
	c0=(struct c0_dev*)kmalloc(sizeof(struct c0_dev),GFP_KERNEL);
	ret=alloc_chrdev_region(&c0->dev_num,0,1,"c0_dev");
	if (ret)
	{
		printk("alloc chrdev failed\n");
		return ret;
	}
	c0->mydev=cdev_alloc();
	if(!c0->mydev)
	{
		printk("cdev alloc failed\n");
		goto err1;
	}
	cdev_init(c0->mydev,&c0_fops);

	ret=cdev_add(c0->mydev,c0->dev_num,1);
	if(ret)
	{
		printk("cdev add failed\n");
		goto err2;
	}
	c0->devcls = class_create(THIS_MODULE,"c0_dev");
	device_create(c0->devcls,NULL,c0->dev_num,NULL,"c0_dev");
	printk("%s major : %d, minor : %d\n",__func__,MAJOR(c0->dev_num),MINOR(c0->dev_num));
	return 0;

err1:
	unregister_chrdev_region(c0->dev_num,1);
err2:
	cdev_del(c0->mydev);

	return ret;
}

static void __exit dev_exit(void)
{
	printk("----%s----\n",__func__);
	device_destroy(c0->devcls,MKDEV(c0->dev_num,0));
	class_destroy(c0->devcls);
	cdev_del(c0->mydev);
	unregister_chrdev_region(c0->dev_num,1);
	kfree(c0);
}

module_init(dev_init);
module_exit(dev_exit);
MODULE_LICENSE("GPL");

