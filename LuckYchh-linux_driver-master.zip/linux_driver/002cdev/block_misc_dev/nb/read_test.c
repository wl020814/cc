#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#define DEVICE "/dev/misc_c0"

int main()
{
	int fd=0;
	int ret;
	char buf[64]={0};
	fd = open(DEVICE,O_RDWR | O_NONBLOCK);
	if(fd<0)
	{
		perror("fd open");
		exit(1);
	}
	memset(buf,0,sizeof(buf));
	ret = read(fd,buf,sizeof(buf));
	if(ret<0)
		printf("read none\n");
	else
		printf("read %d bytes ,buf=%s\n",ret,buf);
	close(fd);
	return 0;
}


