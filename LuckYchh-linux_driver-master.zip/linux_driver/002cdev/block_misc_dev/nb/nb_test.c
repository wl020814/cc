#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#define DEVICE "/dev/misc_c0"

int main()
{
	char wbuf[64]="test fifo device";
	char rbuf[128];
	int ret;
	int fd;
	fd = open(DEVICE,O_RDWR | O_NONBLOCK);
	if(fd<0)
	{
		printf("open failed\n");
		return -1;
	}

	ret = write(fd,wbuf,sizeof(wbuf));
	if(ret<0)
	{
		printf("write failed\n");
		return -1;
	}

	ret = read(fd,rbuf,sizeof(rbuf));
	printf("read %d bytes, rbuf : %s\n",ret,rbuf);

	close(fd);

	return 0;
}
