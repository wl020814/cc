#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#define DEVICE "/dev/misc_c0"

int main()
{
	int fd;
	int ret;
	char buf[64]="no block fifo test";
	while(1)
	{
		//fd = open(DEVICE,O_RDWR | O_NONBLOCK);
		fd = open(DEVICE,O_RDWR);
		if(fd<0)
		{
			perror("fd open");
			exit(1);
		}
		ret = write(fd,buf,strlen(buf)+1);  //'\0'
		printf("buf size : %d \n",strlen(buf)+1);
		printf("write %d bytes \n",ret); 
		sleep(8);
	}

	close(fd);
	return 0;
}

