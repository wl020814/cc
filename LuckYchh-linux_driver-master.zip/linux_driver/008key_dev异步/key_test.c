#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>

#define KEY_ENTER 28

static int fd;
static struct key_user event;

struct key_user{
	int type;
	int value;
};

void catch_signal(int signo)
{
	if(signo==SIGIO)
	{
		printf("get signal\n");
		read(fd,&event,sizeof(struct key_user));
		if(event.type==KEY_ENTER)
		{
			if(event.value)
			{
				printf("APP___ key enter pressed\n");
			}
			else
			{
				printf("APP___ key enter up\n");
			}
		}
		
	}
}

int main(int argc, const char *argv[])
{
	int flags;
	char in_buf[128];

	fd=open("/dev/key_lucky",O_RDWR);
	if(fd<0)
	{
		perror("open");
		exit(1);
	}
	
//	设置信号处理方法
	signal(SIGIO,catch_signal);
//	当前进程设置成SIGIO的主进程
	fcntl(fd,F_SETOWN,getpid());
//	IO模式设为异步
	flags=fcntl(fd,F_GETFL);
	fcntl(fd,F_SETFL,flags|FASYNC);

	while(1)
	{//可以做其他事情
		printf("I LOVE YOU\n");
		sleep(1);
	}

	close(fd);
	return 0;
}
