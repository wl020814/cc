#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>

#define KEY_ENTER 28

struct key_user{
	int type;
	int value;
};

int main(int argc, const char *argv[])
{
	struct key_user event;
	int fd;
	int ret;
	char in_buf[128];

	fd=open("/dev/key_lucky",O_RDWR);
	if(fd<0)
	{
		perror("open");
		exit(1);
	}
	struct pollfd pfd[2];
	pfd[0].fd=fd;
	pfd[0].events=POLLIN;
	pfd[1].fd=0;
	pfd[1].events=POLLIN;


	while(1)
	{
//无期限监控两个fd
		ret=poll(pfd,2,-1);
		printf("ret=%d\n",ret);
		if(ret>0)
		{
			if(pfd[0].revents & POLLIN)
			{
				read(pfd[0].fd,&event,sizeof(struct key_user));
				if(event.type==KEY_ENTER)
				{
					if(event.value)
					{
						printf("APP___ key enter pressed\n");
					}
					else
					{

						printf("APP___ key enter up\n");
					}
				}

			}
			if(pfd[1].revents & POLLIN)
			{
				fgets(in_buf,128,stdin);
				printf("in_buf=%s\n",in_buf);
			}
		}
		else
		{
			perror("poll");
			exit(1);

		}
	}

	close(pfd[0].fd);
	return 0;
}
