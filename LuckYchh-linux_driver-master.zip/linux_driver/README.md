# linux_driver

#### Description
linux driver code test.


对于驱动熟悉的人来讲，后续的开发可以使用misc方式进行注册驱动，统一了主设备号。可以参考：
002cdev/test_dev/misc_dev.c