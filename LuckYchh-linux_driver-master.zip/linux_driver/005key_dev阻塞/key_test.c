#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#define KEY_ENTER 28

struct key_user{
	int type;
	int value;
};

int main(int argc, const char *argv[])
{
	struct key_user event;
	int fd;
	fd=open("/dev/key_lucky",O_RDWR);
	if(fd<0)
	{
		perror("open");
		exit(1);
	}


	while(1)
	{
		read(fd,&event,sizeof(struct key_user));
		if(event.type==KEY_ENTER)
		{
			if(event.value)
			{
				printf("APP___ key enter pressed\n");
			}
			else
			{
				
				printf("APP___ key enter up\n");
			}
		}
	}

	close(fd);
	return 0;
}
