#include <linux/init.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/slab.h>

static int flag = 0;
module_param(flag,int,S_IRUGO|S_IWUSR);

struct list_test{
	int data;
	struct list_head list;
};

LIST_HEAD(test_list);
struct list_test *list1;
struct list_test *list2;

static int __init list_init(void) 
{
	int i;
	for(i=0;i<100;i++)
	{
		list1 = (struct list_test *)kmalloc(sizeof(struct list_test),GFP_KERNEL); 
		list1->data = i;
		if(flag==0)
			list_add_tail(&list1->list,&test_list);
		else
			list_add(&list1->list,&test_list);
			
	}
	i=0;
	printk("show the list\n");
	list_for_each_entry(list1,&test_list,list)
	{
		printk("%02d",list1->data);
		if((i+1)%10==0) printk("\n");
		i++;
	}
	printk("\n");

	return 0;
}

static void __exit list_exit(void)
{
	list_for_each_entry_safe(list1,list2,&test_list,list)
	{
		list_del(&list1->list);
		kfree(list1);
	}
	if(list_empty(&list1->list))
		printk("list free success\n");
}



module_init(list_init);
module_exit(list_exit);
MODULE_LICENSE("GPL");
