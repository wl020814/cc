#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_irq.h>
#include <linux/interrupt.h>


#define U32_DATA_LEN 4

static int aaaaa;

static int __init dt_drv_init(void)
{

	// �ڴ����л�ȡ�ڵ��������Ϣ
	//�Ȱѽڵ��ȡ��
	struct device_node *np = NULL;
	
	
	np = of_find_node_by_path("/test_nod@05201314");
	if(np){
		printk("find test node ok\n");
		printk("node name = %s\n", np->name);
		printk("node full name = %s\n", np->full_name);

	}else{
		printk("find test node failed\n");

	}

	//��ȡ���ڵ��е�����
	struct property *prop = NULL;
	prop = of_find_property(np, "compatible",NULL);
	if(prop)
	{
		printk("find compatible ok\n");
		printk("compatible value = %s\n", prop->value);
		printk("compatible name = %s\n", prop->name);
	}else{
		printk("find compatible failed\n");

	}

	if(of_device_is_compatible(np, "chh,test"))
	{
		printk("we have a compatible named chh,test\n");
	}

	//��ȡ�������е�����������
	
	u32 regdata[U32_DATA_LEN];
	int ret;
	
	ret = of_property_read_u32_array(np, "reg", regdata, U32_DATA_LEN);
	if(!ret)
	{
		int i;
		for(i=0; i<U32_DATA_LEN; i++)
			printk("----regdata[%d] = 0x%x\n", i,regdata[i]);
		
	}else{
		printk("get reg data failed\n");
	}

	//��ȡ�������е��ַ���������
	const char *pstr[3];

	int i;
	for(i=0; i<3; i++)
	{
		ret = of_property_read_string_index(np, "test_list_string", i, &pstr[i]);
		if(!ret)
		{
			printk("----pstr[%d] = %s\n", i,pstr[i]);
		}else{
			printk("get pstr data failed\n");
		}
	}

	// ���Ե�ֵΪ�գ�ʵ�ʿ����������ñ�־
	if(of_find_property(np, "testprop,mytest", NULL))
	{
			aaaaa = 1;
			printk("aaaaa = %d\n", aaaaa);
	}
}

static void __exit dt_drv_exit(void)
{

}

module_init(dt_drv_init);
module_exit(dt_drv_exit);
MODULE_LICENSE("GPL");


