#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

int fd;
char buf[128];

void catch_signal(int signo)
{
	if(signo==SIGIO)
	{
		printf("get signal\n");
		read(fd,buf,128);
		printf("buf : %s\n",buf);
	}
}

int main()
{
	int flags;
	fd=open("/dev/c0",O_RDWR);
	if(fd<0)
	{
		perror("open");
		exit(1);
	}
			
	signal(SIGIO,catch_signal);

	fcntl(fd,F_SETOWN,getpid());

	flags=fcntl(fd,F_GETFL);
	fcntl(fd,F_SETFL,flags|FASYNC);

	while(1)
	{
		printf("I LOVE YOU\n");
		sleep(1);
	}
	close(fd);
	return 0;
}

