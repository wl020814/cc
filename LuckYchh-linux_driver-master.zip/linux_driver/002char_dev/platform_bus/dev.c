#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>

struct resource c0_res[]={
	[0]={
		.start = 0x10,
		.end = 0x10 + 0x04,
		.flags = IORESOURCE_MEM,
	},

	[1]={
		.start = 0x20,
		.end = 0x20 + 0x04,
		.flags = IORESOURCE_MEM,
	},
};

struct platform_device pc0 = {
	.name = "c0", 
	.id = -1,
	.num_resources = ARRAY_SIZE(c0_res),
	.resource = c0_res,
};


static int __init plat_chrdev_init(void)
{
	return platform_device_register(&pc0);
}

static void __exit plat_chrdev_exit(void)
{
	platform_device_unregister(&pc0);
}

module_init(plat_chrdev_init);
module_exit(plat_chrdev_exit);
MODULE_LICENSE("GPL");

