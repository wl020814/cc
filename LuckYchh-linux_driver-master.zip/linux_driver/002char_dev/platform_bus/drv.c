#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/platform_device.h>


struct c0_dev{
	unsigned int dev_major;
	struct class *devcls;
	struct device *dev;
	struct resource *res;
};
struct c0_dev *pc0;


int c0_open(struct inode *inode,struct file *filp)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}
ssize_t c0_read(struct file *filp,char __user *buf,size_t count,loff_t *fpos)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}
ssize_t c0_write(struct file *filp,const char __user *buf,size_t count,loff_t *fpos)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}
int c0_close(struct inode *inode,struct file *filp)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}

const struct file_operations my_fops={
	.open = c0_open,
	.read = c0_read,
	.write = c0_write,
	.release = c0_close,
};

int c0_probe(struct platform_device *pdev)
{
	printk("---------%s--------\n",__FUNCTION__);
	pc0=(struct c0_dev*)kmalloc(sizeof(struct c0_dev),GFP_KERNEL);
	pc0->dev_major=register_chrdev(0,"chr_dev_test",&my_fops);
	pc0->devcls = class_create(THIS_MODULE,"chr_cls");
	pc0->dev = device_create(pc0->devcls,NULL,MKDEV(pc0->dev_major,0),NULL,"c0");
	pc0->res = platform_get_resource(pdev, IORESOURCE_MEM, 0);

	return 0;
}

int c0_remove(struct platform_device *pdev)
{
	printk("---------%s--------\n",__FUNCTION__);
	device_destroy(pc0->devcls, MKDEV(pc0->dev_major, 0));
	class_destroy(pc0->devcls);
	unregister_chrdev(pc0->dev_major, "chr_dev_test");
	kfree(pc0);
								
	return 0;
}

const struct platform_device_id c0_id_table[] = {
	{"c0", 0x1},
	{"c1", 0x2},
};	

struct platform_driver pc0_drv = {
	.probe = c0_probe,
	.remove = c0_remove,
	.driver = {
		.name = "c0_drv",
	},
	.id_table = c0_id_table,
};

static int __init plat_chrdrv_init(void)
{
	return platform_driver_register(&pc0_drv);
}

static void __exit plat_chrdrv_exit(void)
{
	platform_driver_unregister(&pc0_drv);
}

module_init(plat_chrdrv_init);
module_exit(plat_chrdrv_exit);
MODULE_LICENSE("GPL");
