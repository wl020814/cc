#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>

int c0bus_match(struct device *dev, struct device_driver *drv)
{
	if(!strncmp(drv->name,dev->kobj.name,strlen(drv->name)))
	{
		printk("match ok\n");
		return 1;
	}
	else
	{
		printk("match failed\n");
		return 0;
	}
	return 0;
}

struct bus_type c0_bus={
	.name="c0_bus",
	.match=c0bus_match,
};
EXPORT_SYMBOL(c0_bus);

static int __init c0_bus_init(void)
{
	int ret;
	printk("----------%s-------------\n", __FUNCTION__);
	ret = bus_register(&c0_bus);
	if(ret != 0)
	{
		printk("bus_register error\n");
		return ret;
	}
											
	return 0;
}
			
static void __exit c0_bus_exit(void)
{
	printk("----------%s-------------\n",__FUNCTION__);
	bus_unregister(&c0_bus);				
}

module_init(c0_bus_init);
module_exit(c0_bus_exit);
MODULE_LICENSE("GPL");

