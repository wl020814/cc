#ifndef __DEV_H_
#define __DEV_H_

struct c0_infom
{
	char *name;
	int val;
};


#endif
