#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include "dev.h"

struct c0_infom c0_info={
	.name="c0_dev",
	.val=520,
};

extern struct bus_type c0_bus;

void c0dev_rel(struct device *dev)
{
	printk("----------%s-------------\n", __FUNCTION__);
}

struct device  c0_dev= {
	.init_name = "c0_chrdev",
	.bus = &c0_bus,
	.platform_data = &c0_info,
	.release = c0dev_rel,
};

static int __init c0_dev_init(void)
{
	printk("------%s------\n",__FUNCTION__);
	int ret = device_register(&c0_dev);
	if(ret<0)
	{
		printk("device_register err\n");
		return ret;
	}
	return 0;
}

static void __exit c0_dev_exit(void)
{
	printk("-------%s------\n",__FUNCTION__);
	device_unregister(&c0_dev);
}

module_init(c0_dev_init);
module_exit(c0_dev_exit);
MODULE_LICENSE("GPL");

