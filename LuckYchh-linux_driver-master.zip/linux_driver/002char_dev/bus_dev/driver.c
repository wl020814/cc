#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include "dev.h"

extern struct bus_type c0_bus;


int c0drv_probe(struct device *dev)
{
	printk("----------%s--------------\n",__FUNCTION__);
	struct c0_infom *pdev;
	pdev=(struct c0_infom *)dev->platform_data;
	printk("c0 name: %s\n",pdev->name);
	printk("c0 val: %d\n",pdev->val);
	return 0;
}


struct device_driver c0_drv = {
	.name = "c0_chrdev",
	.bus = &c0_bus,
	.probe = c0drv_probe,
};

static int __init c0_drv_init(void)
{
	printk("----------%s-------------\n", __FUNCTION__);
	int ret;
	ret  = driver_register(&c0_drv);
	if(ret < 0)
	{
		printk("device_register error\n");
		return ret;
	}

	return 0;
}

static void __exit c0_drv_exit(void)
{
	printk("----------%s-------------\n", __FUNCTION__);
	driver_unregister(&c0_drv);
}

module_init(c0_drv_init);
module_exit(c0_drv_exit);
MODULE_LICENSE("GPL");

