#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#if 0
int main()
{
	FILE *fp=NULL;
	char buf[128]={0};
	fp = fopen("/dev/c0","r+");
	if(fp==NULL)
	{
		perror("fd open");
		exit(1);
	}
	fread(buf,sizeof(buf),1,fp);
	printf("buf=%s\n",buf);

	fclose(fp);
	return 0;
}
#else
int main()
{
	int fd=0;
	char buf[128]={0};
	fd = open("/dev/c0",O_RDWR);
	if(fd<0)
	{
		perror("fd open");
		exit(1);
	}
	read(fd,buf,sizeof(buf));
	printf("buf=%s\n",buf);

	close(fd);
	return 0;
}

#endif

