#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#if 1
int main()
{
	int fd;
	char buf[128]={0};
	fd = open("/dev/c0",O_RDWR);
	if(fd<0)
	{
		perror("fd open");
		exit(1);
	}
	strcpy(buf,"c0 dev");
	printf("buf=%s\n",buf);
	write(fd,buf,sizeof(buf));

	sleep(5);
	close(fd);
	return 0;
}
#else
int main()
{
	FILE *fp=NULL;
	char buf[128]={0};
	fp = fopen("/dev/c0","r+");
	if(fp == NULL)
	{
		perror("fd open");
		exit(1);
	}
	strcpy(buf,"c0 dev");
	printf("buf=%s\n",buf);
	fwrite(buf,sizeof(buf),1,fp);

	sleep(5);
	fclose(fp);
	return 0;
}

#endif

