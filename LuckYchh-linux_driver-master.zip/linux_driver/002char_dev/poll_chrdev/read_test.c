#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/time.h>
#include <fcntl.h>
#include <stdlib.h>
#include <poll.h>

#if 0

int main()
{
	int fd=0;
	int ret=0;
	char buf[128]={0};
	char in_buf[128]={0};
	if((fd = open("/dev/c0",O_RDWR))<0)
	{
		perror("open");
		exit(1);
	}
	struct pollfd pfd[2];

	pfd[0].fd=fd;
	pfd[0].events=POLLIN;
	pfd[1].fd=0;
	pfd[1].events=POLLIN;

	while(1)
	{
		ret = poll(pfd,2,-1);
		if(ret > 0)
		{
			if(pfd[0].revents & POLLIN)
			{
				read(pfd[0].fd, buf, sizeof(buf));
				printf("buf : %s\n",buf);
			}
			if(pfd[1].revents & POLLIN)
			{
				fgets(in_buf,sizeof(in_buf),stdin);
				printf("in_buf : %s\n",in_buf);
			}  
		}
		else
		{
			perror("poll");
			exit(1);
		}
	}

	close(pfd[0].fd);
	return 0;
}


#else
int main()
{
	int fd=0;
	fd_set rds;
	char buf[128]={0};
	char in_buf[128]={0};
	fd = open("/dev/c0",O_RDWR);
	if(fd<0)
	{
		perror("fd open");
		exit(1);
	}
	FD_ZERO(&rds);
	FD_SET(fd,&rds);
	FD_SET(0,&rds);

	while(1){
	int ret=select(fd+1,&rds,NULL,NULL,NULL);
	if(ret < 0) 
	{
		printf("select error!\n");
		 exit(1);
	}
	if(FD_ISSET(fd, &rds))
	{
		read(fd,buf,sizeof(buf));
		printf("buf=%s\n",buf);
	}
	if(FD_ISSET(fd,&rds))
	{
		fgets(in_buf, sizeof(in_buf),stdin);
		printf("in_buf : %s",in_buf);
	}
	}
	close(fd);
	return 0;
}


#endif
