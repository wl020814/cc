#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>

static unsigned int dev_major;
static struct class *devcls;
static struct device *dev;
const struct file_operations my_fops;

static int __init chr_dev_init(void)
{
	dev_major = register_chrdev(0,"dy_chr_dev_test",&my_fops);
	printk("major: %d\n",dev_major);

	devcls = class_create(THIS_MODULE,"chr_cls");
	dev = device_create(devcls,NULL,MKDEV(dev_major,0),NULL,"c0");

	return 0;
}

static void __exit chr_dev_exit(void)
{
	device_destroy(devcls,MKDEV(dev_major,0));
	class_destroy(devcls);
	unregister_chrdev(0,"dy_chr_dev_test");
	printk("exit ok\n");
}

module_init(chr_dev_init);
module_exit(chr_dev_exit);
MODULE_LICENSE("GPL");

