#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
	int fd;
	int value = 0,kvalue = 250;
	fd = open("/dev/c0",O_RDWR);
	if(fd<0)
	{
		perror("fd open");
		exit(1);
	}
	read(fd,&value,sizeof(value));
	printf("value=%d\n",value);
	write(fd,&kvalue,sizeof(value));

	close(fd);
	return 0;
}

