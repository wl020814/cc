#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/err.h>


struct c0_dev{
	unsigned int dev_major;
	struct class *devcls;
	struct device *dev;
	int value;
	int kvalue;
};
struct c0_dev *c0;


int c0_open(struct inode *inode,struct file *filp)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}
ssize_t c0_read(struct file *filp,char __user *buf,size_t count,loff_t *fpos)
{
	c0->kvalue = 520;
	if(copy_to_user(buf,&c0->kvalue,count)!=0)
	{
		printk("copy_to_user failed\n");
		return -EFAULT;
	}
	return 0;
}
ssize_t c0_write(struct file *filp,const char __user *buf,size_t count,loff_t *fpos)
{
	if(copy_from_user(&c0->value,buf,count)!= 0)
	{
		printk("copy_from_user failed\n");
		return -EFAULT;
	}
	printk("kernel value: %d\n",c0->value);
	return 0;
}
int c0_close(struct inode *inode,struct file *filp)
{
	printk("---------%s--------\n",__FUNCTION__);
	return 0;
}

const struct file_operations my_fops={
	.open = c0_open,
	.read = c0_read,
	.write = c0_write,
	.release = c0_close,
};


static int __init chr_dev_init(void)
{
	int ret;
	c0=(struct c0_dev*)kmalloc(sizeof(struct c0_dev),GFP_KERNEL);
	if(IS_ERR(c0))
	{
		printk("kmalloc falied\n");
		ret = -ENODEV;
		goto err_0;
	}
	c0->dev_major=register_chrdev(0,"chr_dev_test",&my_fops);
	if(c0->dev_major<0)
	{
		printk("register failed\n");
		ret = -ENODEV;
		goto err_1;
	}
	c0->devcls = class_create(THIS_MODULE,"chr_cls");
	if(IS_ERR(c0->devcls))
	{
		printk("class create failed\n");
		ret = PTR_ERR(c0->devcls);
		goto err_2;
	}

	c0->dev = device_create(c0->devcls,NULL,MKDEV(c0->dev_major,0),NULL,"c0");
	if(IS_ERR(c0->dev))
	{
		printk("device create failed\n");
		ret = PTR_ERR(c0->dev);
		goto err_3;
	}

	return 0;

err_3:
	device_destroy(c0->devcls,MKDEV(c0->dev_major,0));
err_2:
	class_destroy(c0->devcls);
err_1:
	unregister_chrdev(c0->dev_major,"chr_dev_test");
err_0:
	kfree(c0);
	return ret;
}

static void __exit chr_dev_exit(void)
{
	device_destroy(c0->devcls,MKDEV(c0->dev_major,0));
	class_destroy(c0->devcls);
	unregister_chrdev(c0->dev_major,"chr_dev_test");
	kfree(c0);
	printk("exit ok\n");
}

module_init(chr_dev_init);
module_exit(chr_dev_exit);
MODULE_LICENSE("GPL");

