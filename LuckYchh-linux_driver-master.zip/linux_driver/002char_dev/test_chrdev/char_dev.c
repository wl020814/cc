#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>

//静态指定设备号
static unsigned int dev_major = 500;
static struct class *devcls;
static struct device *dev;


ssize_t chr_drv_open(struct inode *inode,struct file *filp)
{
	printk("----%s----\n",__FUNCTION__);
	return 0;
}
ssize_t chr_drv_read(struct file *filp,char __user *buf,size_t count,loff_t *fpos)
{
	printk("----%s----\n",__FUNCTION__);
	return 0;
}
ssize_t chr_drv_write(struct file *filp,const char __user *buf,size_t count,loff_t *fpos)
{
	printk("----%s----\n",__FUNCTION__);
	return 0;
}
ssize_t chr_drv_close(struct inode *inode,struct file *filp)
{
	printk("----%s----\n",__FUNCTION__);
	return 0;
}
const struct file_operations my_fops = {
	.open = chr_drv_open,//对open赋值
	.read = chr_drv_read,
	.write = chr_drv_write,
	.release = chr_drv_close,
};


static int __init chr_dev_init(void)
{
	//申请设备号资源
	int ret;
	ret=register_chrdev(dev_major,"chr_dev_test",&my_fops);
	if(ret==0)
	{
		printk("register ok\n");
	}
	else
	{
		printk("register failed\n");
		return -EINVAL;
	}

	devcls = class_create(THIS_MODULE,"chr_cls");
	dev = device_create(devcls,NULL,MKDEV(dev_major,0),NULL,"chr2");

	return 0;
}

static void __exit chr_dev_exit(void)
{
	//释放设备号
	device_destroy(devcls,MKDEV(dev_major,0));
	class_destroy(devcls);
	unregister_chrdev(dev_major,"chr_dev_test");

}

module_init(chr_dev_init);
module_exit(chr_dev_exit);
MODULE_LICENSE("GPL");

